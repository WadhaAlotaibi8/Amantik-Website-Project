// src/utils/phone.ts
// Normalize numbers so: "+96555551234" == "+965 5555 1234" == "965-5555-1234"
// Keeps a leading + if present. Everything else becomes digits.

export function normalizePhone(input: string): string {
  if (!input) return "";

  const raw = String(input).trim();
  const hasPlus = raw.startsWith("+");

  // keep digits only
  const digits = raw.replace(/\D/g, "");
  if (!digits) return "";

  return hasPlus ? `+${digits}` : digits;
}

export function isProbablyPhoneQuery(q: string): boolean {
  // If user typed at least 3 digits, treat it as phone query.
  const digits = (q || "").replace(/\D/g, "");
  return digits.length >= 3;
}
