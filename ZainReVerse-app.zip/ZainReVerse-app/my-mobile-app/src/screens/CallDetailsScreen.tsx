import React, { useMemo, useState } from "react";
import {
  SafeAreaView,
  View,
  Text,
  Pressable,
  ScrollView,
  Alert,
  ActivityIndicator,
  Platform,
} from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { ChevronLeft, FileText, ShieldPlus, EyeOff } from "lucide-react-native";

import { useFlags } from "../context/FlagsContext";
import { MOCK_CALLS } from "../data/mockCalls";
import { MOCK_HISTORY } from "../data/mockHistory";

import { s } from "../styles/callDetailsStyles";

// A small unified view model so this one screen can render any source (call/history/flag)
type UnifiedDetails = {
  id: string;
  number: string;
  score: number;
  level: "low" | "medium" | "high"; // unified risk level
  title: string; // "Potential Scam Detected" etc
  summary: string;
  keywords: string[];
  timeLabel: string;
  duration: string;
};

function toUnifiedFromCalls(id: string): UnifiedDetails | null {
  const c = MOCK_CALLS.find((x) => x.id === id);
  if (!c) return null;

  const title =
    c.level === "high"
      ? "Potential Scam Detected"
      : c.level === "medium"
      ? "Suspicious Activity"
      : "Low Risk";

  return {
    id: c.id,
    number: c.number,
    score: c.score,
    level: c.level,
    title,
    summary: c.transcriptSummary ?? "No summary available.",
    keywords: c.keywords ?? [],
    timeLabel: c.timeLabel ?? "—",
    duration: c.duration ?? "—",
  };
}

function toUnifiedFromHistory(id: string): UnifiedDetails | null {
  const h = MOCK_HISTORY.find((x) => x.id === id);
  if (!h) return null;

  // map history risk to a unified level
  const level =
    h.status === "ignored" ? "medium" : h.risk === "scam" ? "high" : h.risk === "safe" ? "low" : "medium";

  const title =
    level === "high"
      ? "Potential Scam Detected"
      : level === "medium"
      ? "Suspicious Activity"
      : "Low Risk";

  return {
    id: h.id,
    number: h.number,
    score: h.score,
    level,
    title,
    summary: h.reason || "No reason available.",
    keywords: [],
    timeLabel: new Date(h.analyzedAt).toLocaleString(),
    duration: "—",
  };
}

export function CallDetailsScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id?: string }>();

  const { addFlag, existsByNumber, getById } = useFlags();
  const [busy, setBusy] = useState<"none" | "pdf" | "ignore">("none");

  const details = useMemo<UnifiedDetails | null>(() => {
    const theId = String(id || "").trim();
    if (!theId) return null;

    // 1) Try detect calls
    const fromCalls = toUnifiedFromCalls(theId);
    if (fromCalls) return fromCalls;

    // 2) Try flags (flag id)
    const flag = getById?.(theId);
    if (flag) {
      const title =
        flag.level === "high"
          ? "Potential Scam Detected"
          : flag.level === "medium"
          ? "Suspicious Activity"
          : "Low Risk";

      return {
        id: flag.id,
        number: flag.number,
        score: flag.score ?? 0,
        level: flag.level,
        title,
        summary: flag.notes || flag.reason || "No details available.",
        keywords: flag.keywords ?? [],
        timeLabel: flag.time ?? "—",
        duration: flag.duration ?? "—",
      };
    }

    // 3) Try history (history id)
    const fromHistory = toUnifiedFromHistory(theId);
    if (fromHistory) return fromHistory;

    return null;
  }, [id, getById]);

  const goBack = () => {
    if (router.canGoBack()) router.back();
    else router.replace("/detect");
  };

  const onAddToFlag = () => {
    if (!details?.number?.trim()) {
      Alert.alert("Error", "Phone number is missing.");
      return;
    }

    if (existsByNumber(details.number)) {
      Alert.alert("Already Added", "This number is already in your Flag List.");
      return;
    }

    const flagItem = {
      id: details.id, // keep id (works fine for mock mode)
      number: details.number,
      level: details.level,
      reason: details.title,
      notes: details.summary,
      score: details.score,
      keywords: details.keywords,
      time: details.timeLabel,
      duration: details.duration,
    };

    const res = addFlag(flagItem as any);

    if (res.ok) {
      const pts = res.pointsAwarded ?? 0;
      Alert.alert("Done ✅", `${res.message}${pts ? `\n\n+${pts} points earned ⭐` : ""}`);
    } else {
      Alert.alert("Notice", res.message);
    }
  };

  const onIgnore = () => {
    Alert.alert("Ignore this call?", "This will dismiss it (mock mode). Later we connect to backend.", [
      { text: "Cancel", style: "cancel" },
      { text: "Ignore", style: "default", onPress: () => goBack() },
    ]);
  };

  const escapeHtml = (str: string) =>
    (str || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

  const onReportPdf = async () => {
    if (!details) return;

    if (Platform.OS === "web") {
      Alert.alert("Not Supported", "PDF generation is not supported on web preview.");
      return;
    }
    if (busy !== "none") return;

    setBusy("pdf");
    try {
      let Print: any;
      let Sharing: any;
      try {
        Print = await import("expo-print");
        Sharing = await import("expo-sharing");
      } catch {
        Alert.alert("Missing Packages", "Run:\n\nnpx expo install expo-print expo-sharing\n\nThen restart with -c");
        return;
      }

      const canShare = await Sharing.isAvailableAsync?.();
      if (!canShare) {
        Alert.alert("Sharing Not Available", "Your device cannot share files right now.");
        return;
      }

      const html = `
        <html>
          <head><meta charset="utf-8" /></head>
          <body style="font-family: -apple-system, Arial; padding: 24px; color: #0f172a;">
            <h2 style="text-align:center;">Zain ReVerse - Call Report</h2>
            <p><b>Number:</b> ${escapeHtml(details.number)}</p>
            <p><b>Risk:</b> ${escapeHtml(details.title)}</p>
            <p><b>Score:</b> ${details.score}/100</p>
            <p><b>Time:</b> ${escapeHtml(details.timeLabel)}</p>
            <p><b>Duration:</b> ${escapeHtml(details.duration)}</p>
            <hr/>
            <p><b>Summary:</b> ${escapeHtml(details.summary)}</p>
            <p><b>Keywords:</b> ${escapeHtml((details.keywords || []).join(", "))}</p>
          </body>
        </html>
      `;

      const { uri } = await Print.printToFileAsync({ html });
      await Sharing.shareAsync(uri);
    } finally {
      setBusy("none");
    }
  };

  if (!details) {
    return (
      <SafeAreaView style={s.safe}>
        <View style={s.container}>
          <Text style={s.headerTitle}>Nothing to show</Text>
          <Text style={s.note}>
            This usually means the passed id doesn’t exist in Calls, Flags, or History mock data.
          </Text>

          <Pressable onPress={goBack} style={({ pressed }) => [s.primaryBtn, pressed && s.pressed]}>
            <Text style={s.primaryText}>Back</Text>
          </Pressable>
        </View>
      </SafeAreaView>
    );
  }

  const badge =
    details.level === "high"
      ? { label: "Scam", kind: "scam" as const }
      : details.level === "medium"
      ? { label: "Unknown", kind: "unknown" as const }
      : { label: "Safe", kind: "safe" as const };

  return (
    <SafeAreaView style={s.safe}>
      <ScrollView contentContainerStyle={s.container}>
        <View style={s.headerRow}>
          <Pressable onPress={goBack} style={({ pressed }) => [s.backBtn, pressed && s.pressed]}>
            <ChevronLeft color="#0F172A" size={22} />
            <Text style={s.backText}>Back</Text>
          </Pressable>

          <Text style={s.headerTitle}>Call Details</Text>
          <View style={{ width: 64 }} />
        </View>

        <View style={s.card}>
          <View style={s.topLine}>
            <Text style={s.number}>{details.number}</Text>

            <View
              style={[
                s.badge,
                badge.kind === "scam" ? s.badgeScam : badge.kind === "safe" ? s.badgeSafe : s.badgeUnknown,
              ]}
            >
              <Text
                style={[
                  s.badgeText,
                  badge.kind === "scam"
                    ? s.badgeScamText
                    : badge.kind === "safe"
                    ? s.badgeSafeText
                    : s.badgeUnknownText,
                ]}
              >
                {badge.label}
              </Text>
            </View>
          </View>

          <Text style={s.meta}>Score: {details.score}/100</Text>
          <Text style={s.meta}>
            {details.timeLabel} • Duration: {details.duration}
          </Text>

          <Text style={s.sectionTitle}>Summary</Text>
          <Text style={s.sectionBody}>{details.summary}</Text>

          <Text style={s.sectionTitle}>Keywords</Text>
          <Text style={s.sectionBody}>{(details.keywords || []).join(", ") || "No keywords."}</Text>
        </View>

        <View style={s.actions}>
          <Pressable onPress={onAddToFlag} style={({ pressed }) => [s.secondaryBtn, pressed && s.pressed]}>
            <ShieldPlus color="#2563EB" size={18} />
            <Text style={s.secondaryText}>Add to Flag List</Text>
          </Pressable>

          <Pressable onPress={onIgnore} style={({ pressed }) => [s.dangerBtn, pressed && s.pressed]}>
            <EyeOff color="#EF4444" size={18} />
            <Text style={s.dangerText}>Ignore</Text>
          </Pressable>

          <Pressable onPress={onReportPdf} style={({ pressed }) => [s.primaryBtn, pressed && s.pressed]}>
            {busy === "pdf" ? <ActivityIndicator color="#fff" /> : <FileText color="#FFFFFF" size={18} />}
            <Text style={s.primaryText}>Report (PDF)</Text>
          </Pressable>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
