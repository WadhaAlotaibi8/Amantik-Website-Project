// src/data/mockFlags.ts
export type RiskLevel = "low" | "medium" | "high";

export type FlagItem = {
  id: string;
  callId: string;        // ✅ required by FlagsContext
  createdAtISO: string;  // ✅ required by FlagsContext

  number: string;
  level: RiskLevel;
  reason: string;
  notes?: string;

  score: number;
  keywords: string[];

  time: string;
  duration: string;
};

export const MOCK_FLAGS: FlagItem[] = [
  {
    id: "f1",
    callId: "c1",
    createdAtISO: new Date().toISOString(),
    number: "+965 5555 1234",
    level: "high",
    reason: "Potential Scam Detected",
    notes: "Asked for OTP + urgent payment.",
    score: 92,
    keywords: ["OTP", "KNET", "urgent"],
    time: "Today, 9:10 PM",
    duration: "2:01",
  },
  {
    id: "f2",
    callId: "c2",
    createdAtISO: new Date().toISOString(),
    number: "+965 6999 8899",
    level: "medium",
    reason: "Suspicious Activity",
    notes: "Identity request without clear context.",
    score: 55,
    keywords: ["civil id", "confirm"],
    time: "Yesterday, 1:20 PM",
    duration: "1:22",
  },
];
