export type ProfileUser = {
  id: string;
  name: string;
  email: string;
  phone: string;
};

export const MOCK_PROFILE_USER: ProfileUser = {
  id: "u1",
  name: "Fatema",
  email: "fatema@example.com",
  phone: "+965 5xxxxxxx",
};
