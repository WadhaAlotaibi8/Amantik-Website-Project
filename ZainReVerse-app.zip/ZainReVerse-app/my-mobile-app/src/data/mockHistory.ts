export type RiskLevel = "scam" | "safe" | "unknown";
export type CallStatus = "active" | "ignored";
export type TimelineTag = "none" | "flagged" | "reported" | "ignored";

export type HistoryCall = {
  id: string;
  number: string;
  name?: string;
  risk: RiskLevel;
  status: CallStatus;
  timelineTag: TimelineTag; // ✅ Flagged / Ignored / Reported
  score: number; // 0 - 100
  reason: string; // short explanation
  analyzedAt: string; // ISO string
  duration: string; // ✅ "1:12"
};

export const MOCK_HISTORY: HistoryCall[] = [
  {
    id: "c1",
    number: "+965 5555 1234",
    name: "Unknown",
    risk: "scam",
    status: "active",
    timelineTag: "flagged",
    score: 92,
    reason: "Urgent payment + suspicious keywords",
    analyzedAt: "2026-02-15T10:20:00Z",
    duration: "2:01",
  },
  {
    id: "c2",
    number: "+965 6999 8899",
    name: "Bank Caller?",
    risk: "unknown",
    status: "active",
    timelineTag: "reported",
    score: 55,
    reason: "Identity request (unclear context)",
    analyzedAt: "2026-02-14T19:05:00Z",
    duration: "1:22",
  },
  {
    id: "c3",
    number: "5123 7777",
    name: "Delivery",
    risk: "safe",
    status: "active",
    timelineTag: "none",
    score: 18,
    reason: "Normal delivery conversation pattern",
    analyzedAt: "2026-02-13T14:30:00Z",
    duration: "0:30",
  },
  {
    id: "c4",
    number: "9000 1111",
    name: "Spam",
    risk: "scam",
    status: "ignored",
    timelineTag: "ignored",
    score: 88,
    reason: "Repeated calls + link request",
    analyzedAt: "2026-02-12T08:10:00Z",
    duration: "0:55",
  },
];
