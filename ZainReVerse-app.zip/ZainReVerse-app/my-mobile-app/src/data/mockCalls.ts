// src/data/mockCalls.ts
export type CallRiskLevel = "low" | "medium" | "high";
export type CallTimelineStatus = "none" | "flagged" | "ignored" | "reported";

export type CallItem = {
  id: string;
  number: string; // can be "Unknown Number"
  score: number; // 0 - 100
  level: CallRiskLevel; // low/medium/high
  status: CallTimelineStatus; // ✅ for timeline tag
  timestampISO: string; // ✅ for consistent time formatting
  timeLabel: string; // "Today, 3:45 PM"
  duration: string; // "2:00"
  transcriptSummary: string;
  keywords: string[];
};

export const MOCK_CALLS: CallItem[] = [
  {
    id: "c1",
    number: "+965 5000 1234",
    score: 82,
    level: "high",
    status: "flagged",
    timestampISO: "2026-02-15T15:45:00Z",
    timeLabel: "Today, 3:45 PM",
    duration: "2:00",
    transcriptSummary:
      "Caller claimed your bank account is locked and asked you to verify details urgently.",
    keywords: ["urgent", "verify", "account"],
  },
  {
    id: "c2",
    number: "Unknown Number",
    score: 18,
    level: "low",
    status: "none",
    timestampISO: "2026-02-15T13:10:00Z",
    timeLabel: "Today, 1:10 PM",
    duration: "0:42",
    transcriptSummary:
      "General conversation. No pressure, no sensitive info requested.",
    keywords: [],
  },
  {
    id: "c3",
    number: "+965 6999 7711",
    score: 55,
    level: "medium",
    status: "reported",
    timestampISO: "2026-02-14T21:05:00Z",
    timeLabel: "Yesterday, 9:05 PM",
    duration: "1:12",
    transcriptSummary:
      "Caller offered a suspicious service, asked for personal confirmation. Not fully aggressive but unclear.",
    keywords: ["confirm", "offer"],
  },
];
