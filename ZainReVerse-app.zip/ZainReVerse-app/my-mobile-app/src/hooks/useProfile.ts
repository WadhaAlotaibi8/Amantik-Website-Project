import { useCallback, useEffect, useState } from "react";
import type { ProfileUser } from "../data/mockProfile";
import { getProfileUser, updateProfileUser } from "../services/profileService";

export function useProfile() {
  const [user, setUser] = useState<ProfileUser | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const u = await getProfileUser();
      setUser(u);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const savePatch = useCallback(async (patch: Partial<ProfileUser>) => {
    const updated = await updateProfileUser(patch);
    setUser(updated);
    return updated;
  }, []);

  return { user, loading, refresh, savePatch };
}
