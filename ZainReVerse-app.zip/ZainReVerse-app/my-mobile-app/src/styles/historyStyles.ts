import { StyleSheet } from "react-native";

const C = {
  bg: "#FFFFFF",
  text: "#0F172A",
  muted: "#64748B",
  border: "#E5E7EB",
  blue: "#2563EB",
  softBlue: "rgba(37,99,235,0.08)",
  softRed: "rgba(239,68,68,0.10)",
  red: "#EF4444",
  green: "#16A34A",
  softGreen: "rgba(22,163,74,0.10)",
};

export const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },
  container: { padding: 18, paddingBottom: 26 },

  pressed: { opacity: 0.95, transform: [{ scale: 0.99 }] },

  headerRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 14,
  },
  title: { color: C.text, fontSize: 22, fontWeight: "900" },

  search: {
    borderWidth: 1,
    borderColor: C.border,
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 12,
    color: C.text,
    backgroundColor: "#FFFFFF",
  },

  chipRow: { flexDirection: "row", flexWrap: "wrap", gap: 10, marginTop: 12 },
  chip: {
    paddingHorizontal: 12,
    paddingVertical: 9,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: C.border,
    backgroundColor: "#FFFFFF",
  },
  chipActive: { borderColor: C.blue, backgroundColor: C.softBlue },
  chipText: { color: C.muted, fontWeight: "800" },
  chipTextActive: { color: C.blue },

  listCard: {
    marginTop: 14,
    borderWidth: 1,
    borderColor: C.border,
    borderRadius: 18,
    overflow: "hidden",
    backgroundColor: "#FFFFFF",
  },

  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: 14,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: C.border,
    gap: 10,
  },
  rowLast: { borderBottomWidth: 0 },

  left: { flex: 1 },
  topLine: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10 },
  number: { color: C.text, fontWeight: "900", fontSize: 16 },
  name: { color: "#94A3B8", fontWeight: "700", marginTop: 3 },

  meta: { marginTop: 8, color: C.muted, fontWeight: "700", fontSize: 12.5 },

  badge: { alignSelf: "flex-start", paddingHorizontal: 10, paddingVertical: 6, borderRadius: 999, borderWidth: 1 },
  badgeText: { fontWeight: "900", fontSize: 12 },

  badgeScam: { backgroundColor: C.softRed, borderColor: "rgba(239,68,68,0.30)" },
  badgeScamText: { color: C.red },

  badgeSafe: { backgroundColor: C.softGreen, borderColor: "rgba(22,163,74,0.30)" },
  badgeSafeText: { color: C.green },

  badgeUnknown: { backgroundColor: C.softBlue, borderColor: "rgba(37,99,235,0.25)" },
  badgeUnknownText: { color: C.blue },

  empty: { marginTop: 16, color: "#94A3B8", fontWeight: "800" },
});
