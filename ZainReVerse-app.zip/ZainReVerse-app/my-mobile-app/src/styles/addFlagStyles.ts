import { StyleSheet, Platform } from "react-native";

const COLORS = {
  bg: "#FFFFFF",
  text: "#0F172A",
  muted: "#64748B",
  border: "#E5E7EB",
  blue: "#2563EB",
  blueSoft: "rgba(37,99,235,0.10)",
  red: "#EF4444",
  redSoft: "rgba(239,68,68,0.08)",
  card: "#FFFFFF",
  overlay: "rgba(15,23,42,0.45)",
};

export const addFlagStyles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },

  scroll: {
    paddingHorizontal: 16,
    paddingTop: 14,
    paddingBottom: 24,
    ...(Platform.OS === "web" ? { alignItems: "center" as const } : null),
  },

  content: {
    width: "100%",
    maxWidth: 620,
  },

  backRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    alignSelf: "flex-start",
    paddingVertical: 8,
    paddingHorizontal: 8,
    borderRadius: 12,
  },

  backArrow: { fontSize: 18, color: COLORS.text, fontWeight: "900" },
  backText: { fontSize: 14, color: COLORS.text, fontWeight: "800" },

  title: { fontSize: 26, fontWeight: "900", color: COLORS.text, marginTop: 6 },
  subtitle: { color: COLORS.muted, fontWeight: "700", marginTop: 6, marginBottom: 14 },

  card: {
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 18,
    backgroundColor: COLORS.card,
    padding: 14,
  },

  sectionTitle: { color: COLORS.text, fontWeight: "900", marginTop: 14, marginBottom: 8 },

  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },

  countryBtn: {
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 14,
    paddingHorizontal: 12,
    paddingVertical: 12,
    backgroundColor: "#fff",
    minWidth: 150,
    alignItems: "center",
    justifyContent: "center",
  },

  countryBtnSelected: {
    borderColor: "rgba(37,99,235,0.30)",
    backgroundColor: COLORS.blueSoft,
  },

  countryText: { color: COLORS.text, fontWeight: "900" },
  countrySub: { color: COLORS.muted, fontWeight: "700", fontSize: 12, marginTop: 2 },

  input: {
    flex: 1,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 14,
    paddingHorizontal: 12,
    paddingVertical: 12,
    fontWeight: "800",
    color: COLORS.text,
    backgroundColor: "#fff",
  },

  inputError: {
    borderColor: "rgba(239,68,68,0.45)",
    backgroundColor: COLORS.redSoft,
  },

  errorText: {
    marginTop: 8,
    color: COLORS.red,
    fontWeight: "800",
  },

  notesBox: { minHeight: 110, textAlignVertical: "top" },

  radioGroup: { gap: 10, marginTop: 4 },

  radioRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingVertical: 10,
    paddingHorizontal: 10,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: COLORS.border,
    backgroundColor: "#fff",
  },

  radioRowSelected: {
    borderColor: "rgba(37,99,235,0.30)",
    backgroundColor: COLORS.blueSoft,
  },

  radioOuter: {
    width: 20,
    height: 20,
    borderRadius: 999,
    borderWidth: 2,
    borderColor: "#94A3B8",
    alignItems: "center",
    justifyContent: "center",
  },
  radioOuterSelected: { borderColor: COLORS.blue },
  radioInner: { width: 10, height: 10, borderRadius: 999, backgroundColor: COLORS.blue },

  radioText: { color: COLORS.text, fontWeight: "800" },

  hint: { marginTop: 12, color: COLORS.muted, fontWeight: "700", lineHeight: 20 },
  hintStrong: { color: COLORS.text, fontWeight: "900" },

  submitBtn: {
    marginTop: 14,
    backgroundColor: COLORS.blue,
    borderRadius: 16,
    paddingVertical: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  submitBtnDisabled: { opacity: 0.5 },
  submitText: { color: "#fff", fontWeight: "900", fontSize: 15 },

  pressed: { transform: [{ scale: 0.99 }], opacity: 0.96 },

  // ✅ Modal styles
  modalOverlay: {
    flex: 1,
    backgroundColor: COLORS.overlay,
    padding: 16,
    justifyContent: "center",
    alignItems: "center",
  },

  modalCard: {
    width: "100%",
    maxWidth: 520,
    backgroundColor: "#fff",
    borderRadius: 18,
    borderWidth: 1,
    borderColor: COLORS.border,
    overflow: "hidden",
  },

  modalHeader: {
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  modalTitle: { fontWeight: "900", fontSize: 16, color: COLORS.text },
  modalClose: { fontWeight: "900", color: COLORS.muted },

  countryItem: {
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  countryItemSelected: {
    backgroundColor: COLORS.blueSoft,
  },

  countryItemLeft: { gap: 2 },
  countryItemName: { fontWeight: "900", color: COLORS.text },
  countryItemHint: { fontWeight: "700", color: COLORS.muted, fontSize: 12 },

  countryItemDial: { fontWeight: "900", color: COLORS.text },
});
