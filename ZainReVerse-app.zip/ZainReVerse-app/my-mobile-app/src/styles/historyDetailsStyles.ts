import { StyleSheet } from "react-native";

const C = {
  bg: "#FFFFFF",
  text: "#0F172A",
  muted: "#64748B",
  border: "#E5E7EB",
  blue: "#2563EB",
  softBlue: "rgba(37,99,235,0.08)",
  red: "#EF4444",
  softRed: "rgba(239,68,68,0.10)",
  green: "#16A34A",
  softGreen: "rgba(22,163,74,0.10)",
};

export const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },
  container: { padding: 18, paddingBottom: 26 },

  pressed: { opacity: 0.95, transform: [{ scale: 0.99 }] },

  headerRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 14 },
  headerTitle: { color: C.text, fontSize: 18, fontWeight: "900" },

  backBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 10,
    borderRadius: 12,
    backgroundColor: "#F8FAFC",
    borderWidth: 1,
    borderColor: C.border,
  },
  backText: { color: C.text, fontWeight: "800" },

  title: { color: C.text, fontSize: 22, fontWeight: "900" },
  note: { marginTop: 8, color: "#94A3B8", fontWeight: "800" },

  card: { borderWidth: 1, borderColor: C.border, borderRadius: 18, padding: 14, backgroundColor: "#FFFFFF" },

  topLine: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10 },
  number: { color: C.text, fontSize: 18, fontWeight: "900" },
  name: { marginTop: 4, color: "#94A3B8", fontWeight: "700" },

  meta: { marginTop: 10, color: C.muted, fontWeight: "700" },

  reasonTitle: { marginTop: 12, color: C.text, fontWeight: "900" },
  reason: { marginTop: 6, color: C.muted, fontWeight: "700", lineHeight: 20 },

  badge: { alignSelf: "flex-start", paddingHorizontal: 10, paddingVertical: 6, borderRadius: 999, borderWidth: 1 },
  badgeText: { fontWeight: "900", fontSize: 12 },

  badgeScam: { backgroundColor: C.softRed, borderColor: "rgba(239,68,68,0.30)" },
  badgeScamText: { color: C.red },

  badgeSafe: { backgroundColor: C.softGreen, borderColor: "rgba(22,163,74,0.30)" },
  badgeSafeText: { color: C.green },

  badgeUnknown: { backgroundColor: C.softBlue, borderColor: "rgba(37,99,235,0.25)" },
  badgeUnknownText: { color: C.blue },

  actions: { marginTop: 14, gap: 10 },

  primaryBtn: {
    backgroundColor: C.blue,
    borderRadius: 18,
    paddingVertical: 14,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: 10,
  },
  primaryText: { color: "#FFFFFF", fontWeight: "900" },

  secondaryBtn: {
    borderWidth: 1,
    borderColor: C.border,
    backgroundColor: "#FFFFFF",
    borderRadius: 18,
    paddingVertical: 14,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: 10,
  },
  secondaryText: { color: C.blue, fontWeight: "900" },

  dangerBtn: {
    borderWidth: 1,
    borderColor: "rgba(239,68,68,0.35)",
    backgroundColor: "#FFFFFF",
    borderRadius: 18,
    paddingVertical: 14,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: 10,
  },
  dangerText: { color: C.red, fontWeight: "900" },
});
