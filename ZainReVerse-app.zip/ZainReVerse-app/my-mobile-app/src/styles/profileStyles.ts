import { StyleSheet } from "react-native";

const COLORS = {
  bg: "#FFFFFF",
  text: "#0F172A",
  muted: "#64748B",
  border: "#E5E7EB",
  blue: "#2563EB",
  softBlue: "rgba(37,99,235,0.08)",
  softBlue2: "rgba(37,99,235,0.06)",
};

export const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  container: { paddingBottom: 30 },

  pressed: { transform: [{ scale: 0.99 }], opacity: 0.96 },
  rowPressed: { opacity: 0.92, transform: [{ scale: 0.995 }] },

  // Header card
  headerCard: {
    marginTop: 14,
    marginHorizontal: 18,
    backgroundColor: "#FFFFFF",
    borderRadius: 18,
    padding: 16,
    borderWidth: 1,
    borderColor: COLORS.border,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  avatar: {
    width: 52,
    height: 52,
    borderRadius: 14,
    backgroundColor: COLORS.softBlue,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: COLORS.softBlue2,
  },
  name: { color: COLORS.text, fontSize: 20, fontWeight: "900" },
  phone: { color: COLORS.muted, marginTop: 2, fontWeight: "700" },
  subtitle: { color: "#94A3B8", marginTop: 2, fontWeight: "700" },

  editBtn: {
    backgroundColor: COLORS.blue,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 14,
  },
  editBtnText: { color: "#FFFFFF", fontWeight: "900" },

  // Stats
  statsCard: {
    marginTop: 14,
    marginHorizontal: 18,
    backgroundColor: "#FFFFFF",
    borderRadius: 18,
    borderWidth: 1,
    borderColor: COLORS.border,
    flexDirection: "row",
    overflow: "hidden",
  },
  statBox: { flex: 1, paddingVertical: 14, alignItems: "center" },
  statBorder: { borderLeftWidth: 1, borderLeftColor: COLORS.border },
  statValue: { color: COLORS.text, fontSize: 20, fontWeight: "900" },
  statLabel: { color: COLORS.muted, marginTop: 4, fontWeight: "700" },

  // Section titles
  sectionTitle: {
    marginTop: 18,
    marginHorizontal: 18,
    fontSize: 22,
    fontWeight: "900",
    color: COLORS.text,
  },

  // List card
  listCard: {
    marginTop: 12,
    marginHorizontal: 18,
    backgroundColor: "#FFFFFF",
    borderRadius: 18,
    borderWidth: 1,
    borderColor: COLORS.border,
    overflow: "hidden",
  },

  row: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 14,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  rowLeft: { flexDirection: "row", alignItems: "center", gap: 12, flex: 1 },

  iconWrap: {
    width: 40,
    height: 40,
    borderRadius: 14,
    backgroundColor: COLORS.softBlue,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: COLORS.softBlue2,
  },

  rowTitle: { color: COLORS.text, fontWeight: "900", fontSize: 16 },
  rowSub: { color: "#94A3B8", marginTop: 2, fontWeight: "700", fontSize: 13.5 },

  // Logout
  logoutBtn: {
    marginTop: 16,
    marginHorizontal: 18,
    borderRadius: 18,
    paddingVertical: 14,
    borderWidth: 1,
    borderColor: "rgba(239, 68, 68, 0.35)",
    backgroundColor: "rgba(239, 68, 68, 0.08)",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
  },
  logoutText: { color: "#EF4444", fontWeight: "900" },

    rowLast: { borderBottomWidth: 0 },

    loadingRow: {
    marginTop: 10,
    marginHorizontal: 18,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    },

    loadingText: {
    color: "#64748B",
    fontWeight: "800",
    },

});
