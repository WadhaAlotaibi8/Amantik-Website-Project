import { StyleSheet } from "react-native";

export const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#FFFFFF" },
  container: { padding: 18, paddingBottom: 26 },

  pressed: { opacity: 0.92, transform: [{ scale: 0.99 }] },

  headerRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 14,
  },
  headerTitle: { color: "#0F172A", fontSize: 18, fontWeight: "900" },

  backBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#E5E7EB",
    backgroundColor: "#F8FAFC",
  },
  backText: { color: "#0F172A", fontWeight: "900" },

  card: {
    borderWidth: 1,
    borderColor: "#E5E7EB",
    borderRadius: 18,
    padding: 14,
    backgroundColor: "#FFFFFF",
  },
  topLine: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 10,
  },
  number: { color: "#0F172A", fontSize: 18, fontWeight: "900" },
  meta: { marginTop: 10, color: "#64748B", fontWeight: "700" },

  sectionTitle: { marginTop: 14, color: "#0F172A", fontWeight: "900" },
  sectionBody: { marginTop: 6, color: "#64748B", fontWeight: "700", lineHeight: 20 },

  badge: {
    alignSelf: "flex-start",
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    borderWidth: 1,
  },
  badgeText: { fontWeight: "900", fontSize: 12 },

  badgeScam: { backgroundColor: "rgba(239,68,68,0.10)", borderColor: "rgba(239,68,68,0.30)" },
  badgeScamText: { color: "#EF4444" },

  badgeSafe: { backgroundColor: "rgba(22,163,74,0.10)", borderColor: "rgba(22,163,74,0.30)" },
  badgeSafeText: { color: "#16A34A" },

  badgeUnknown: { backgroundColor: "rgba(37,99,235,0.08)", borderColor: "rgba(37,99,235,0.25)" },
  badgeUnknownText: { color: "#2563EB" },

  actions: { marginTop: 14, gap: 12 },

  // ✅ Base button sizing (applies via each button style below)
  btnBase: {
    width: "100%",
    minHeight: 52,
    borderRadius: 18,
    paddingVertical: 14,
    paddingHorizontal: 14,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: 10,
  },

  // ✅ Primary: strong + shadow
  primaryBtn: {
    backgroundColor: "#2563EB",
    borderRadius: 18,
    paddingVertical: 14,
    paddingHorizontal: 14,
    minHeight: 52,
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: 10,

    // shadow (mobile + web)
    shadowColor: "#2563EB",
    shadowOpacity: 0.22,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 6 },
    elevation: 4,
  },
  primaryText: { color: "#FFFFFF", fontWeight: "900" },

  // ✅ Secondary: soft blue tint, still looks clickable
  secondaryBtn: {
    borderWidth: 1,
    borderColor: "rgba(37,99,235,0.22)",
    backgroundColor: "rgba(37,99,235,0.06)",
    borderRadius: 18,
    paddingVertical: 14,
    paddingHorizontal: 14,
    minHeight: 52,
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: 10,
  },
  secondaryText: { color: "#2563EB", fontWeight: "900" },

  // ✅ Danger: soft red tint, not too loud
  dangerBtn: {
    borderWidth: 1,
    borderColor: "rgba(239,68,68,0.28)",
    backgroundColor: "rgba(239,68,68,0.06)",
    borderRadius: 18,
    paddingVertical: 14,
    paddingHorizontal: 14,
    minHeight: 52,
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: 10,
  },
  dangerText: { color: "#EF4444", fontWeight: "900" },

  note: { marginTop: 8, color: "#94A3B8", fontWeight: "800", lineHeight: 20 },
});
