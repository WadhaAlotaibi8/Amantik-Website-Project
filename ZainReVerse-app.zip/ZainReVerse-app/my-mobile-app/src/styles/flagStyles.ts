import { StyleSheet } from "react-native";

const COLORS = {
  bg: "#FFFFFF",
  text: "#0F172A",
  muted: "#64748B",
  border: "#E5E7EB",
  blue: "#2563EB",
};

export const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  container: { flex: 1, paddingHorizontal: 16, paddingTop: 14, paddingBottom: 18 },

  pressed: { transform: [{ scale: 0.99 }], opacity: 0.96 },

  headerRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 12,
  },
  title: { color: COLORS.text, fontSize: 22, fontWeight: "900" },

  addBtn: {
    backgroundColor: COLORS.blue,
    borderRadius: 14,
    paddingHorizontal: 12,
    paddingVertical: 10,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  addText: { color: "#fff", fontWeight: "900" },

  searchRow: { flexDirection: "row", gap: 10, marginBottom: 10 },
  searchBox: {
    flex: 1,
    borderWidth: 1,
    borderColor: COLORS.border,
    backgroundColor: "#fff",
    borderRadius: 14,
    paddingHorizontal: 12,
    paddingVertical: 10,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  searchInput: { flex: 1, color: COLORS.text, fontWeight: "800" },

  /* ✅ Filter pills */
  filterRow: { flexDirection: "row", gap: 10, marginBottom: 12 },
  filterPill: {
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: COLORS.border,
    backgroundColor: "#FFFFFF",
  },
  filterPillActive: {
    backgroundColor: "rgba(37,99,235,0.10)",
    borderColor: "rgba(37,99,235,0.30)",
  },
  filterPillText: { fontWeight: "900", color: COLORS.muted },
  filterPillTextActive: { color: COLORS.blue },

  card: {
    borderWidth: 1,
    borderColor: COLORS.border,
    backgroundColor: "#fff",
    borderRadius: 18,
    padding: 14,
    marginBottom: 12,
  },
  cardTop: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 10,
  },
  badgeRow: { flexDirection: "row", alignItems: "center", gap: 8 },

  /* ✅ Optional polish: risk chip colors */
  levelChipBase: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    borderWidth: 1,
  },
  levelTextBase: { fontWeight: "900", fontSize: 12 },

  levelChipHigh: { backgroundColor: "rgba(239,68,68,0.10)", borderColor: "rgba(239,68,68,0.30)" },
  levelTextHigh: { color: "#EF4444" },

  levelChipMedium: { backgroundColor: "rgba(245,158,11,0.12)", borderColor: "rgba(245,158,11,0.35)" },
  levelTextMedium: { color: "#F59E0B" },

  levelChipLow: { backgroundColor: "rgba(22,163,74,0.10)", borderColor: "rgba(22,163,74,0.30)" },
  levelTextLow: { color: "#16A34A" },

  /* ✅ Score colors */
  scoreText: { fontWeight: "900" },
  scoreBad: { color: "#EF4444" },   // 0-39
  scoreMid: { color: "#F59E0B" },   // 40-69
  scoreGood: { color: "#16A34A" },  // 70-100

  numberText: { color: COLORS.text, fontSize: 16, fontWeight: "900" },
  reasonText: { color: COLORS.muted, marginTop: 6, fontWeight: "800" },
  notesText: { color: COLORS.muted, marginTop: 6, fontWeight: "700" },

  emptyTitle: { color: COLORS.text, fontWeight: "900", fontSize: 16 },
  emptySub: { color: COLORS.muted, fontWeight: "700", marginTop: 6, lineHeight: 20 },
});
