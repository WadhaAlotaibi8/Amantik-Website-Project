import { StyleSheet } from "react-native";

const COLORS = {
  bg: "#FFFFFF",
  text: "#0F172A",
  muted: "#64748B",
  border: "#E5E7EB",
  blue: "#2563EB",
  ring1: "rgba(37,99,235,0.08)",
  ring2: "rgba(37,99,235,0.06)",
  ring3: "rgba(37,99,235,0.04)",
};

export const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  pressed: { transform: [{ scale: 0.99 }], opacity: 0.96 },
  cardPressed: { opacity: 0.92, transform: [{ scale: 0.995 }] },

  brand: {
    textAlign: "center",
    fontSize: 34,
    fontWeight: "900",
    color: COLORS.text,
    marginTop: 14,
  },
  tagline: {
    textAlign: "center",
    marginTop: 6,
    fontSize: 15,
    color: COLORS.muted,
    fontWeight: "600",
  },

  heroWrap: {
    marginTop: 18,
    paddingHorizontal: 18,
    alignItems: "center",
  },

  // the circular detection button + soft rings background
  heroCircle: {
    width: 240,
    height: 240,
    borderRadius: 999,
    backgroundColor: COLORS.blue,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "transparent",
    elevation: 0,

    borderWidth: 18,
    borderColor: COLORS.ring1,
  },
  heroCircleOff: {
    backgroundColor: "#9AA5B1",
  },
  heroTitle: {
    marginTop: 14,
    fontSize: 30,
    fontWeight: "900",
    color: "#FFFFFF",
  },

  statusRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    marginTop: 18,
  },
  statusText: { fontSize: 22, fontWeight: "900", color: COLORS.blue },
  statusHint: {
    marginTop: 10,
    fontSize: 18,
    color: COLORS.muted,
    textAlign: "center",
    paddingHorizontal: 10,
  },

  sectionHead: {
    marginTop: 26,
    paddingHorizontal: 18,
  },
  sectionTitle: {
    fontSize: 32,
    fontWeight: "900",
    color: COLORS.text,
  },
  sectionSub: {
    marginTop: 6,
    fontSize: 14.5,
    color: "#94A3B8",
    fontWeight: "600",
  },

  listContent: {
    paddingBottom: 30,
  },

  callCard: {
    marginTop: 14,
    marginHorizontal: 18,
    backgroundColor: "#FFFFFF",
    borderRadius: 18,
    padding: 16,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  callRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  dot: { width: 12, height: 12, borderRadius: 999 },
  callNumber: { fontSize: 20, fontWeight: "900", color: COLORS.text },
  callMeta: { marginTop: 6, fontSize: 15, color: COLORS.muted, fontWeight: "700" },
  callTime: { marginTop: 6, fontSize: 14, color: "#94A3B8", fontWeight: "700" },

  emptyWrap: {
    marginTop: 14,
    marginHorizontal: 18,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 18,
    padding: 18,
    backgroundColor: "#FFFFFF",
  },
  emptyTitle: { fontSize: 18, fontWeight: "900", color: COLORS.text },
  emptyText: { marginTop: 8, fontSize: 14.5, color: COLORS.muted, lineHeight: 20 },

  topPanel: {
    paddingBottom: 10,
  },

  recentList: {
    flex: 1,
  },
  sectionHeadRow: {
    marginTop: 18,
    paddingHorizontal: 18,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 12,
  },

  viewAllBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: "#E5E7EB",
    backgroundColor: "rgba(37,99,235,0.06)",
  },

  viewAllText: {
    color: "#2563EB",
    fontWeight: "900",
    fontSize: 14.5,
  },

  previewListContent: {
    paddingBottom: 22,
  },

});
