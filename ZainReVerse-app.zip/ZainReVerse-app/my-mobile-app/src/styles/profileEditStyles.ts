import { StyleSheet } from "react-native";

const C = { bg:"#FFF", text:"#0F172A", muted:"#94A3B8", border:"#E5E7EB", blue:"#2563EB" };

export const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },
  pressed: { opacity: 0.95, transform: [{ scale: 0.99 }] },

  headerRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 16 },
  backBtn: { flexDirection: "row", alignItems: "center", gap: 6, paddingVertical: 8, paddingHorizontal: 10, borderRadius: 12, backgroundColor: "#F8FAFC", borderWidth: 1, borderColor: C.border },
  backText: { color: C.text, fontWeight: "800" },
  headerTitle: { color: C.text, fontSize: 18, fontWeight: "900" },

   headerRight: { alignItems: "flex-end" },

  saveState: {
    marginTop: 2,
    color: "#94A3B8",
    fontWeight: "800",
    fontSize: 12,
    },

    label: {
    marginTop: 10,
    marginBottom: 8,
    color: "#0F172A",
    fontWeight: "900",
    },

    input: {
    borderWidth: 1,
    borderColor: "#E5E7EB",
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 12,
    color: "#0F172A",
    backgroundColor: "#FFFFFF",
    },

    container: {
    padding: 18,
    paddingBottom: 26,
    maxWidth: 900,
    width: "100%",
    alignSelf: "center",
    },

    card: {
    marginTop: 14,
    borderWidth: 1,
    borderColor: "#E5E7EB",
    borderRadius: 18,
    padding: 14,
    backgroundColor: "#FFFFFF",
    },

    loadingWrap: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    },
    loadingText: { color: "#64748B", fontWeight: "800" },

    inputError: { borderColor: "rgba(239, 68, 68, 0.6)" },
    errorText: { marginTop: 8, color: "#EF4444", fontWeight: "800" },

    saveBtn: {
    marginTop: 16,
    backgroundColor: "#2563EB",
    borderRadius: 18,
    paddingVertical: 14,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: 10,
    },
    saveBtnDisabled: { opacity: 0.7 },
    saveText: { color: "#FFFFFF", fontWeight: "900" },
    
});
