import React, { createContext, useContext, useMemo, useState } from "react";
import type { FlagItem } from "../data/mockFlags";
import { normalizePhone } from "../utils/phone";

type AddResult = { ok: boolean; message: string; pointsAwarded?: number };

type FlagsContextValue = {
  flags: FlagItem[];
  points: number;
  addFlag: (item: FlagItem) => AddResult;
  addPoints: (amount: number) => void;
  removeByNumber: (number: string) => void;
  existsByNumber: (number: string) => boolean;
  getById: (id: string) => FlagItem | undefined;
};

const FlagsContext = createContext<FlagsContextValue | null>(null);

// ✅ change this number whenever you want
const POINTS_PER_FLAG = 10;

export function FlagsProvider({
  children,
  initialFlags = [],
}: {
  children: React.ReactNode;
  initialFlags?: FlagItem[];
}) {
  const [flags, setFlags] = useState<FlagItem[]>(initialFlags);
  const [points, setPoints] = useState<number>(0);

  const addPoints = (amount: number) => {
    const n = Number(amount);
    if (!Number.isFinite(n) || n === 0) return;
    setPoints((prev) => Math.max(0, prev + n));
  };

  const existsByNumber = (number: string) => {
    const n = normalizePhone(number);
    if (!n) return false;
    return flags.some((f) => normalizePhone(f.number) === n);
  };

  const addFlag = (item: FlagItem): AddResult => {
    if (!item?.number || !item.number.trim()) {
      return { ok: false, message: "Phone number is missing." };
    }

    if (existsByNumber(item.number)) {
      return { ok: false, message: "This number is already in your Flag List." };
    }

    setFlags((prev) => [item, ...prev]);

    // ✅ award points ONLY when added successfully
    addPoints(POINTS_PER_FLAG);

    return {
      ok: true,
      message: "Added to Flag List.",
      pointsAwarded: POINTS_PER_FLAG,
    };
  };

  const removeByNumber = (number: string) => {
    const n = normalizePhone(number);
    if (!n) return;
    setFlags((prev) => prev.filter((f) => normalizePhone(f.number) !== n));
  };

  const getById = (id: string) => flags.find((f) => f.id === id);

  const value = useMemo(
    () => ({
      flags,
      points,
      addFlag,
      addPoints,
      removeByNumber,
      existsByNumber,
      getById,
    }),
    [flags, points]
  );

  return <FlagsContext.Provider value={value}>{children}</FlagsContext.Provider>;
}

export function useFlags() {
  const ctx = useContext(FlagsContext);
  if (!ctx) throw new Error("useFlags must be used inside FlagsProvider");
  return ctx;
}
