import type { ProfileUser } from "../data/mockProfile";
import { MOCK_PROFILE_USER } from "../data/mockProfile";

// In-memory cache (temporary until backend)
let cachedUser: ProfileUser = { ...MOCK_PROFILE_USER };

export async function getProfileUser(): Promise<ProfileUser> {
  // Later: return fetch("/api/profile").then(r => r.json())
  return cachedUser;
}

export async function updateProfileUser(
  patch: Partial<ProfileUser>
): Promise<ProfileUser> {
  // Later: return fetch("/api/profile", {method:"PUT", body: JSON.stringify(patch)}).then(r=>r.json())
  cachedUser = { ...cachedUser, ...patch };
  return cachedUser;
}
