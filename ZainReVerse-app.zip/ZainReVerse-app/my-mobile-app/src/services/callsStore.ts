import { MOCK_CALLS, CallItem } from "../data/mockCalls";

let cache: CallItem[] = [...MOCK_CALLS];

export function getAllCalls() {
  return cache;
}

export function getCallById(id: string) {
  return cache.find((c) => c.id === id);
}

export function setIgnored(id: string, ignored: boolean) {
  cache = cache.map((c) => (c.id === id ? { ...c, ignored } : c));
  return cache.find((c) => c.id === id);
}
