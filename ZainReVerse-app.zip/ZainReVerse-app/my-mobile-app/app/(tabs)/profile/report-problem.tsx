import React, { useMemo, useState } from "react";
import {
  View,
  Text,
  SafeAreaView,
  TextInput,
  Pressable,
  ScrollView,
  Alert,
  Image,
  Modal,
  Platform,
  TouchableOpacity,
} from "react-native";
import { useRouter } from "expo-router";
import {
  Bug,
  ChevronLeft,
  Send,
  Image as ImageIcon,
  ChevronDown,
  X,
  Check,
} from "lucide-react-native";
import { s } from "../../../src/styles/reportProblemStyles";

type ProblemReason =
  | "Bug"
  | "Wrong Detection"
  | "UI Issue"
  | "Feature Request"
  | "Other";

export default function ReportProblemScreen() {
  const router = useRouter();

  const reasons: ProblemReason[] = useMemo(
    () => ["Bug", "Wrong Detection", "UI Issue", "Feature Request", "Other"],
    []
  );

  const [reason, setReason] = useState<ProblemReason>("Bug");
  const [details, setDetails] = useState("");
  const [screenshotUri, setScreenshotUri] = useState<string | null>(null);
  const [sending, setSending] = useState(false);

  // ✅ Web needs Modal (Alert is unreliable on web for multi-option picker)
  const [reasonOpen, setReasonOpen] = useState(false);

  const openReasonPicker = () => {
    if (Platform.OS === "web") {
      setReasonOpen(true);
      return;
    }

    Alert.alert(
      "Report reason",
      "Choose the closest reason",
      reasons.map((r) => ({ text: r, onPress: () => setReason(r) }))
    );
  };

  const pickScreenshot = async () => {
    try {
      const ImagePicker = await import("expo-image-picker");

      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) {
        Alert.alert(
          "Permission needed",
          "Please allow photo access to attach a screenshot."
        );
        return;
      }

      const res = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        quality: 0.8,
        allowsEditing: false,
      });

      // @ts-ignore (expo-image-picker v14+ uses `canceled`)
      if (res.canceled) return;

      // @ts-ignore
      const uri = res.assets?.[0]?.uri;
      if (uri) setScreenshotUri(uri);
    } catch (e: any) {
      Alert.alert(
        "Screenshot",
        "To enable screenshot attach, install expo-image-picker:\n\nnpx expo install expo-image-picker"
      );
    }
  };

  const onSubmit = async () => {
    if (!details.trim()) {
      Alert.alert(
        "Missing details",
        "Tell us what happened (steps + what you expected). "
      );
      return;
    }

    setSending(true);
    try {
      // ✅ mock send (later replace with backend)
      // await fetch("/api/report-problem", {
      //   method: "POST",
      //   body: JSON.stringify({ reason, details, screenshotUri }),
      // })

      Alert.alert("Thanks!", "Your report was sent.");
      setDetails("");
      setScreenshotUri(null);
      router.back();
    } catch (e: any) {
      Alert.alert("Error", e?.message ?? "Could not send report.");
    } finally {
      setSending(false);
    }
  };

  return (
    <SafeAreaView style={s.safe}>
      <ScrollView contentContainerStyle={s.container}>
        {/* Header */}
        <View style={s.headerRow}>
          <Pressable
            onPress={() => router.back()}
            style={({ pressed }) => [s.backBtn, pressed && s.pressed]}
          >
            <ChevronLeft color="#0F172A" size={22} />
            <Text style={s.backText}>Back</Text>
          </Pressable>

          <View style={s.headerTitleWrap}>
            <Bug color="#2563EB" size={20} />
            <Text style={s.headerTitle}>Report a Problem</Text>
          </View>
        </View>

        {/* Reason dropdown */}
        <Text style={s.label}>Reason</Text>
        <Pressable
          onPress={openReasonPicker}
          style={({ pressed }) => [s.dropdown, pressed && s.pressed]}
        >
          <Text style={s.dropdownText}>{reason}</Text>
          <ChevronDown color="#64748B" size={18} />
        </Pressable>

        {/* Optional screenshot attach */}
        <Text style={s.label}>Screenshot (optional)</Text>
        {screenshotUri ? (
          <View style={s.screenshotWrap}>
            <Image source={{ uri: screenshotUri }} style={s.screenshotImg} />
            <Pressable
              onPress={() => setScreenshotUri(null)}
              style={({ pressed }) => [s.removeShotBtn, pressed && s.pressed]}
            >
              <X color="#0F172A" size={18} />
              <Text style={s.removeShotText}>Remove</Text>
            </Pressable>
          </View>
        ) : (
          <Pressable
            onPress={pickScreenshot}
            style={({ pressed }) => [s.attachBtn, pressed && s.pressed]}
          >
            <ImageIcon color="#0F172A" size={18} />
            <Text style={s.attachText}>Attach screenshot</Text>
          </Pressable>
        )}

        {/* Details */}
        <Text style={s.label}>Details</Text>
        <TextInput
          value={details}
          onChangeText={setDetails}
          placeholder="What happened? Steps to reproduce? What did you expect?"
          placeholderTextColor="#94A3B8"
          style={[s.input, s.textarea]}
          multiline
        />

        {/* Submit */}
        <Pressable
          onPress={onSubmit}
          disabled={sending}
          style={({ pressed }) => [
            s.submitBtn,
            sending && s.disabledBtn,
            pressed && !sending && s.pressed,
          ]}
        >
          <Send color="#FFFFFF" size={18} />
          <Text style={s.submitText}>{sending ? "Sending..." : "Send"}</Text>
        </Pressable>

      </ScrollView>

      {/* ✅ Web Reason Picker Modal */}
      <Modal
        visible={reasonOpen}
        transparent
        animationType="fade"
        onRequestClose={() => setReasonOpen(false)}
      >
        <Pressable
          style={s.modalBackdrop}
          onPress={() => setReasonOpen(false)}
        >
          <Pressable style={s.modalCard} onPress={() => {}}>
            <View style={s.modalHeader}>
              <Text style={s.modalTitle}>Report reason</Text>
              <Pressable
                onPress={() => setReasonOpen(false)}
                style={({ pressed }) => [s.modalCloseBtn, pressed && s.pressed]}
              >
                <X color="#0F172A" size={18} />
              </Pressable>
            </View>

            {reasons.map((r) => {
              const active = r === reason;
              return (
                <TouchableOpacity
                  key={r}
                  onPress={() => {
                    setReason(r);
                    setReasonOpen(false);
                  }}
                  style={[s.modalItem, active && s.modalItemActive]}
                >
                  <Text
                    style={[
                      s.modalItemText,
                      active && s.modalItemTextActive,
                    ]}
                  >
                    {r}
                  </Text>

                  {active ? <Check color="#2563EB" size={18} /> : null}
                </TouchableOpacity>
              );
            })}
          </Pressable>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}
