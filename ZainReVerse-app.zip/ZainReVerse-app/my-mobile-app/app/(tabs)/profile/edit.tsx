import React, { useEffect, useState } from "react";
import {
  SafeAreaView,
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  ActivityIndicator,
  Alert,
  Platform,
  ToastAndroid,
} from "react-native";
import { useRouter } from "expo-router";
import { ChevronLeft, Save } from "lucide-react-native";

import { s } from "../../../src/styles/profileEditStyles";
import { useProfile } from "../../../src/hooks/useProfile";

export default function ProfileEditScreen() {
  const router = useRouter();
  const { user, loading, savePatch } = useProfile();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");

  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!user) return;
    setName(user.name ?? "");
    setEmail(user.email ?? "");
    setPhone(user.phone ?? "");
  }, [user]);

  // ✅ ALWAYS go back to Profile
  const goBackToProfile = () => {
    router.replace("/profile");
  };

  // --- Validation helpers ---
  const normalizeEmail = (v: string) => v.trim().toLowerCase();
  const normalizePhone = (v: string) => v.replace(/\s+/g, "").trim();
  const isEmailValid = (v: string) => {
    const x = normalizeEmail(v);
    // simple but decent email check
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(x);
  };

  // Kuwait numbers: often 8 digits local OR +965XXXXXXXX
  const isKuwaitPhoneValid = (v: string) => {
    const x = normalizePhone(v);
    if (!x) return false;

    // Allow +965XXXXXXXX
    if (/^\+965\d{8}$/.test(x)) return true;

    // Allow 8 digits local (e.g. 5xxxxxxx / 6xxxxxxx / 9xxxxxxx)
    if (/^\d{8}$/.test(x)) return true;

    return false;
  };

  const notify = (msg: string) => {
    if (Platform.OS === "android") {
      ToastAndroid.show(msg, ToastAndroid.SHORT);
      return;
    }
    Alert.alert("Done", msg);
  };

  const onSave = async () => {
    const n = name.trim();
    const e = normalizeEmail(email);
    const p = normalizePhone(phone);

    // ✅ Error checks
    if (!n) return Alert.alert("Missing name", "Please enter your name.");
    if (n.length < 2) return Alert.alert("Name too short", "Please enter a valid name.");
    if (!e) return Alert.alert("Missing email", "Please enter your email.");
    if (!isEmailValid(e)) return Alert.alert("Invalid email", "Please enter a valid email format.");
    if (!p) return Alert.alert("Missing phone", "Please enter your phone number.");

    if (!isKuwaitPhoneValid(p)) {
      return Alert.alert(
        "Invalid phone number",
        "Use 8 digits (e.g. 5xxxxxxx) or +965XXXXXXXX."
      );
    }

    setSaving(true);
    try {
      await savePatch({ name: n, email: e, phone: p });

      // ✅ Success notification
      notify("Profile saved ✅");

      // ✅ go to Profile
      goBackToProfile();
    } catch (err: any) {
      Alert.alert("Save failed", err?.message ?? "Something went wrong.");
    } finally {
      setSaving(false);
    }
  };

  if (loading || !user) {
    return (
      <SafeAreaView style={s.safe}>
        <View style={s.loadingWrap}>
          <ActivityIndicator />
          <Text style={s.loadingText}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  const emailOk = isEmailValid(email.trim());
  const phoneOk = isKuwaitPhoneValid(phone);

  return (
    <SafeAreaView style={s.safe}>
      <ScrollView contentContainerStyle={s.container}>
        {/* Header */}
        <View style={s.headerRow}>
          <Pressable onPress={goBackToProfile} style={({ pressed }) => [s.backBtn, pressed && s.pressed]}>
            <ChevronLeft color="#0F172A" size={22} />
            <Text style={s.backText}>Back</Text>
          </Pressable>

          <Text style={s.headerTitle}>Edit Profile</Text>

          <View style={{ width: 64 }} />
        </View>

        {/* Card */}
        <View style={s.card}>
          <Text style={s.label}>Name</Text>
          <TextInput
            value={name}
            onChangeText={setName}
            style={s.input}
            placeholder="Your name"
            placeholderTextColor="#94A3B8"
          />

          <Text style={s.label}>Email</Text>
          <TextInput
            value={email}
            onChangeText={setEmail}
            style={[s.input, !emailOk && s.inputError]}
            placeholder="you@example.com"
            placeholderTextColor="#94A3B8"
            keyboardType="email-address"
            autoCapitalize="none"
          />
          {!emailOk && <Text style={s.errorText}>Email format should look like name@mail.com</Text>}

          <Text style={s.label}>Phone Number</Text>
          <TextInput
            value={phone}
            onChangeText={setPhone}
            style={[s.input, !phoneOk && s.inputError]}
            placeholder="5xxxxxxx or +965XXXXXXXX"
            placeholderTextColor="#94A3B8"
            keyboardType="phone-pad"
          />
          {!phoneOk && (
            <Text style={s.errorText}>Use 8 digits (5xxxxxxx) or +965XXXXXXXX</Text>
          )}

          {/* Save */}
          <Pressable
            onPress={onSave}
            disabled={saving}
            style={({ pressed }) => [
              s.saveBtn,
              saving && s.saveBtnDisabled,
              pressed && !saving && s.pressed,
            ]}
          >
            <Save color="#FFFFFF" size={18} />
            <Text style={s.saveText}>{saving ? "Saving..." : "Save"}</Text>
          </Pressable>
        </View>

      </ScrollView>
    </SafeAreaView>
  );
}
