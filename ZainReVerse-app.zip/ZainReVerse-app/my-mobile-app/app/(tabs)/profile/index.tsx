import React from "react";
import { View, Text, SafeAreaView, Pressable, ScrollView, ActivityIndicator } from "react-native";
import { useRouter } from "expo-router";
import { User, ShieldAlert, History, Settings, ChevronRight, Info, LogOut, Bug } from "lucide-react-native";

import { s } from "../../../src/styles/profileStyles";
import { useProfile } from "../../../src/hooks/useProfile";
import { useFlags } from "../../../src/context/FlagsContext";

export default function ProfileScreen() {
  const router = useRouter();
  const { user, loading } = useProfile();
  const { flags, points } = useFlags();

  // Keep analyzed/ignored mock for now (until backend)
  const analyzed = 48;
  const ignored = 3;

  const Row = ({
    icon,
    title,
    subtitle,
    onPress,
    isLast,
  }: {
    icon: React.ReactNode;
    title: string;
    subtitle?: string;
    onPress: () => void;
    isLast?: boolean;
  }) => (
    <Pressable onPress={onPress} style={({ pressed }) => [s.row, isLast && s.rowLast, pressed && s.rowPressed]}>
      <View style={s.rowLeft}>
        <View style={s.iconWrap}>{icon}</View>

        <View style={{ flex: 1 }}>
          <Text style={s.rowTitle}>{title}</Text>
          {!!subtitle && <Text style={s.rowSub}>{subtitle}</Text>}
        </View>
      </View>

      <ChevronRight color="#94A3B8" size={20} />
    </Pressable>
  );

  return (
    <SafeAreaView style={s.safe}>
      <ScrollView contentContainerStyle={s.container}>
        {/* Header */}
        <View style={s.headerCard}>
          <View style={s.avatar}>
            <User color="#0F172A" size={28} />
          </View>

          <View style={{ flex: 1 }}>
            <Text style={s.name}>{loading ? "Loading..." : user?.name ?? "—"}</Text>
            <Text style={s.phone}>{loading ? " " : user?.phone ?? "—"}</Text>
            <Text style={s.subtitle}>{loading ? " " : user?.email ?? "—"}</Text>
          </View>

          <Pressable onPress={() => router.push("/profile/edit")} style={({ pressed }) => [s.editBtn, pressed && s.pressed]}>
            <Text style={s.editBtnText}>Edit</Text>
          </Pressable>
        </View>

        {/* Loading indicator */}
        {loading && (
          <View style={s.loadingRow}>
            <ActivityIndicator />
            <Text style={s.loadingText}>Loading profile...</Text>
          </View>
        )}

        {/* Stats card */}
        <View style={s.statsCard}>
          <View style={s.statBox}>
            <Text style={s.statValue}>{points}</Text>
            <Text style={s.statLabel}>Points ⭐</Text>
          </View>

          <View style={[s.statBox, s.statBorder]}>
            <Text style={s.statValue}>{flags.length}</Text>
            <Text style={s.statLabel}>Flagged</Text>
          </View>

          <View style={[s.statBox, s.statBorder]}>
            <Text style={s.statValue}>{analyzed}</Text>
            <Text style={s.statLabel}>Analyzed</Text>
          </View>
        </View>

        {/* Activity */}
        <Text style={s.sectionTitle}>Activity</Text>
        <View style={s.listCard}>
          <Row
            icon={<ShieldAlert color="#2563EB" size={20} />}
            title="Flag List"
            subtitle="View & manage flagged numbers"
            onPress={() => router.push("/profile/flags")}
          />
          <Row
            icon={<History color="#2563EB" size={20} />}
            title="Call History"
            subtitle="See analyzed calls and reports"
            onPress={() => router.push("/profile/history")}
            isLast
          />
        </View>

        {/* Settings */}
        <Text style={s.sectionTitle}>Settings</Text>
        <View style={s.listCard}>
          <Row
            icon={<Settings color="#2563EB" size={20} />}
            title="Preferences"
            subtitle="Notifications, detection options"
            onPress={() => router.push("/profile/settings")}
          />
          <Row
            icon={<Bug color="#2563EB" size={20} />}
            title="Report a Problem"
            subtitle="Send feedback or report an issue"
            onPress={() => router.push("/profile/report-problem")}
          />
          <Row
            icon={<Info color="#2563EB" size={20} />}
            title="Help / About"
            subtitle="App info & support"
            onPress={() => router.push("/profile/about")}
            isLast
          />
        </View>

        {/* Sign out (placeholder) */}
        <Pressable
          onPress={() => {
            // Later: auth logout
          }}
          style={({ pressed }) => [s.logoutBtn, pressed && s.pressed]}
        >
          <LogOut color="#EF4444" size={18} />
          <Text style={s.logoutText}>Sign out</Text>
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}
