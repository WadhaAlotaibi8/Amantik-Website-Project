import React, { useMemo, useState } from "react";
import {
  SafeAreaView,
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
} from "react-native";
import { useRouter } from "expo-router";
import { s } from "../../../src/styles/historyStyles";
import { MOCK_HISTORY, HistoryCall } from "../../../src/data/mockHistory";
import { isProbablyPhoneQuery, normalizePhone } from "../../../src/utils/phone";

type Filter = "all" | "scam" | "safe" | "ignored";

function formatCompactTime(iso: string) {
  try {
    const d = new Date(iso);
    return d.toLocaleString(undefined, {
      month: "short",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return iso;
  }
}

export default function ProfileHistoryScreen() {
  const router = useRouter();
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState<Filter>("all");

  const filtered = useMemo(() => {
    const query = q.trim().toLowerCase();
    const phoneMode = isProbablyPhoneQuery(query);
    const qPhone = phoneMode ? normalizePhone(query) : "";

    return MOCK_HISTORY.filter((c) => {
      // filter
      if (filter === "ignored" && c.timelineTag !== "ignored") return false;
      if (filter === "scam" && c.risk !== "scam") return false;
      if (filter === "safe" && c.risk !== "safe") return false;

      // search
      if (!query) return true;

      // normalize numbers so spacing doesn't matter
      if (phoneMode) {
        const n = normalizePhone(c.number);
        return !!qPhone && n.includes(qPhone.replace(/\D/g, ""));
      }

      const hay = `${c.number} ${c.name ?? ""} ${c.reason}`.toLowerCase();
      return hay.includes(query);
    });
  }, [q, filter]);

  const Chip = ({ id, label }: { id: Filter; label: string }) => {
    const active = id === filter;
    return (
      <Pressable
        onPress={() => setFilter(id)}
        style={({ pressed }) => [
          s.chip,
          active && s.chipActive,
          pressed && s.pressed,
        ]}
      >
        <Text style={[s.chipText, active && s.chipTextActive]}>{label}</Text>
      </Pressable>
    );
  };

  const Badge = ({ c }: { c: HistoryCall }) => {
    if (c.timelineTag === "ignored") {
      return (
        <View style={[s.badge, s.badgeUnknown]}>
          <Text style={[s.badgeText, s.badgeUnknownText]}>Ignored</Text>
        </View>
      );
    }

    if (c.timelineTag === "flagged") {
      return (
        <View style={[s.badge, s.badgeScam]}>
          <Text style={[s.badgeText, s.badgeScamText]}>Flagged</Text>
        </View>
      );
    }

    if (c.timelineTag === "reported") {
      return (
        <View style={[s.badge, s.badgeUnknown]}>
          <Text style={[s.badgeText, s.badgeUnknownText]}>Reported</Text>
        </View>
      );
    }

    if (c.risk === "scam") {
      return (
        <View style={[s.badge, s.badgeScam]}>
          <Text style={[s.badgeText, s.badgeScamText]}>Scam</Text>
        </View>
      );
    }

    if (c.risk === "safe") {
      return (
        <View style={[s.badge, s.badgeSafe]}>
          <Text style={[s.badgeText, s.badgeSafeText]}>Safe</Text>
        </View>
      );
    }

    return (
      <View style={[s.badge, s.badgeUnknown]}>
        <Text style={[s.badgeText, s.badgeUnknownText]}>Unknown</Text>
      </View>
    );
  };

  return (
    <SafeAreaView style={s.safe}>
      <ScrollView contentContainerStyle={s.container}>
        <View style={s.headerRow}>
          <Text style={s.title}>Call History</Text>
        </View>

        <TextInput
          value={q}
          onChangeText={setQ}
          placeholder="Search by number, name, reason..."
          placeholderTextColor="#94A3B8"
          style={s.search}
        />

        <View style={s.chipRow}>
          <Chip id="all" label="All" />
          <Chip id="scam" label="Scam" />
          <Chip id="safe" label="Safe" />
          <Chip id="ignored" label="Ignored" />
        </View>

        <View style={s.listCard}>
          {filtered.length === 0 ? (
            <Text style={s.empty}>No calls match your search.</Text>
          ) : (
            filtered.map((c, idx) => {
              const isLast = idx === filtered.length - 1;
              return (
                <Pressable
                  key={c.id}
                  onPress={() =>
                    router.push({
                      pathname: "/profile/history-details",
                      params: { id: c.id },
                    })
                  }
                  style={({ pressed }) => [
                    s.row,
                    isLast && s.rowLast,
                    pressed && s.pressed,
                  ]}
                >
                  <View style={s.left}>
                    <View style={s.topLine}>
                      <Text style={s.number}>{c.number}</Text>
                      <Badge c={c} />
                    </View>
                    {!!c.name && <Text style={s.name}>{c.name}</Text>}
                    <Text style={s.meta}>
                      {formatCompactTime(c.analyzedAt)} • {c.duration} • Score:{" "}
                      {c.score}/100
                      {c.reason ? ` • ${c.reason}` : ""}
                    </Text>
                  </View>
                </Pressable>
              );
            })
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
