import { Stack } from "expo-router";

export default function ProfileLayout() {
  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="index" />
      <Stack.Screen name="edit" />
      <Stack.Screen name="history" />
      <Stack.Screen name="history-details" />
      <Stack.Screen name="report-problem" />
      <Stack.Screen name="call/[id]" />
    </Stack>
  );
}
