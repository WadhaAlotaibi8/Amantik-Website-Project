import { Stack } from "expo-router";

export default function FlagsLayout() {
  return (
    <Stack>
      <Stack.Screen name="index" options={{ title: "Flags" }} />
      <Stack.Screen name="add" options={{ title: "Add Flag" }} />
      <Stack.Screen name="score" options={{ title: "Risk Score" }} />
    </Stack>
  );
}
