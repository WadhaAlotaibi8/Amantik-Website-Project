import React from "react";
import { CallDetailsScreen } from "../../../../src/screens/CallDetailsScreen";

export default function FlagsCallDetails() {
  return <CallDetailsScreen />;
}
