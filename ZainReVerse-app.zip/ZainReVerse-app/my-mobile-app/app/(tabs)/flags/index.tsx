import React, { useMemo, useState } from "react";
import {
  View,
  Text,
  SafeAreaView,
  StatusBar,
  TextInput,
  Pressable,
  FlatList,
} from "react-native";
import { useRouter } from "expo-router";
import { Search, Plus } from "lucide-react-native";

import { styles } from "../../../src/styles/flagStyles";
import { useFlags } from "../../../src/context/FlagsContext";
import type { FlagItem } from "../../../src/data/mockFlags";

const FILTERS = ["All", "High", "Medium", "Low"] as const;
type FilterType = (typeof FILTERS)[number];

export default function FlagsIndex() {
  const router = useRouter();
  const { flags } = useFlags();

  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<FilterType>("All");

  const data = useMemo(() => {
    const q = query.trim().toLowerCase();

    return (flags as FlagItem[])
      .filter((x) => {
        if (!q) return true;
        return (
          x.number.toLowerCase().includes(q) ||
          x.reason.toLowerCase().includes(q) ||
          (x.notes || "").toLowerCase().includes(q)
        );
      })
      .filter((x) => {
        if (filter === "All") return true;
        if (filter === "High") return x.level === "high";
        if (filter === "Medium") return x.level === "medium";
        return x.level === "low";
      });
  }, [flags, query, filter]);

  const openDetails = (callId: string) => {
    router.push({ pathname: "/flags/call/[id]", params: { id: callId } });
  };

  const renderItem = ({ item }: { item: FlagItem }) => {
    const levelLabel =
      item.level === "high" ? "High" : item.level === "medium" ? "Medium" : "Low";

    // ✅ score color
    const scoreStyle =
      item.score >= 70 ? styles.scoreGood : item.score >= 40 ? styles.scoreMid : styles.scoreBad;

    // ✅ optional polish: chip color by level
    const chipStyle =
      item.level === "high"
        ? styles.levelChipHigh
        : item.level === "medium"
        ? styles.levelChipMedium
        : styles.levelChipLow;

    const chipTextStyle =
      item.level === "high"
        ? styles.levelTextHigh
        : item.level === "medium"
        ? styles.levelTextMedium
        : styles.levelTextLow;

    return (
      <Pressable
        onPress={() => openDetails(item.callId)}
        style={({ pressed }) => [styles.card, pressed && styles.pressed]}
      >
        <View style={styles.cardTop}>
          <View style={styles.badgeRow}>
            <View style={[styles.levelChipBase, chipStyle]}>
              <Text style={[styles.levelTextBase, chipTextStyle]}>{levelLabel}</Text>
            </View>
          </View>

          <Text style={[styles.scoreText, scoreStyle]}>{item.score}/100</Text>
        </View>

        <Text style={styles.numberText}>{item.number}</Text>

        <Text style={styles.reasonText} numberOfLines={2}>
          {item.reason}
        </Text>

        {!!item.notes && (
          <Text style={styles.notesText} numberOfLines={2}>
            {item.notes}
          </Text>
        )}
      </Pressable>
    );
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" />

      <View style={styles.container}>
        <View style={styles.headerRow}>
          <Text style={styles.title}>Flag List</Text>

          <Pressable
            onPress={() => router.push("/flags/add")}
            style={({ pressed }) => [styles.addBtn, pressed && styles.pressed]}
          >
            <Plus size={18} color="#fff" />
            <Text style={styles.addText}>Add</Text>
          </Pressable>
        </View>

        {/* Search */}
        <View style={styles.searchRow}>
          <View style={styles.searchBox}>
            <Search size={18} color="#94A3B8" />
            <TextInput
              value={query}
              onChangeText={setQuery}
              placeholder="Search number / reason…"
              placeholderTextColor="#94A3B8"
              style={styles.searchInput}
            />
          </View>
        </View>

        {/* ✅ New Filter Pills */}
        <View style={styles.filterRow}>
          {FILTERS.map((f) => {
            const active = f === filter;
            return (
              <Pressable
                key={f}
                onPress={() => setFilter(f)}
                style={({ pressed }) => [
                  styles.filterPill,
                  active && styles.filterPillActive,
                  pressed && styles.pressed,
                ]}
              >
                <Text style={[styles.filterPillText, active && styles.filterPillTextActive]}>
                  {f}
                </Text>
              </Pressable>
            );
          })}
        </View>

        <FlatList
          data={data}
          keyExtractor={(item) => item.id}
          renderItem={renderItem}
          contentContainerStyle={{ paddingBottom: 20 }}
          ListEmptyComponent={
            <View style={{ paddingTop: 18 }}>
              <Text style={styles.emptyTitle}>No flagged numbers</Text>
              <Text style={styles.emptySub}>Add suspicious numbers to track them here.</Text>
            </View>
          }
        />
      </View>
    </SafeAreaView>
  );
}
