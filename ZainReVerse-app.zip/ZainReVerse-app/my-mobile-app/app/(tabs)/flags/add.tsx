import React, { useMemo, useState } from "react";
import {
  View,
  Text,
  SafeAreaView,
  StatusBar,
  TextInput,
  Pressable,
  ScrollView,
  Alert,
  Modal,
  FlatList,
} from "react-native";
import { useRouter } from "expo-router";
import { addFlagStyles as s } from "../../../src/styles/addFlagStyles";
import { useFlags } from "../../../src/context/FlagsContext";

type Reason =
  | "Scam call"
  | "Spam/Telemarketing"
  | "Suspicious activity"
  | "Harassment"
  | "Other";

const REASONS: Reason[] = [
  "Scam call",
  "Spam/Telemarketing",
  "Suspicious activity",
  "Harassment",
  "Other",
];

type Country = {
  key: "KW" | "SA" | "US";
  name: string;
  dial: string; // +965
  minDigits: number;
  maxDigits: number;
  hint: string;
};

const COUNTRIES: Country[] = [
  { key: "KW", name: "Kuwait", dial: "+965", minDigits: 8, maxDigits: 8, hint: "8 digits" },
  { key: "SA", name: "Saudi", dial: "+966", minDigits: 9, maxDigits: 9, hint: "9 digits" },
  { key: "US", name: "USA", dial: "+1", minDigits: 10, maxDigits: 10, hint: "10 digits" },
];

function digitsOnly(value: string) {
  return (value || "").replace(/\D/g, "");
}

function reasonToLevel(reason: Reason): "low" | "medium" | "high" {
  if (reason === "Scam call" || reason === "Harassment") return "high";
  if (reason === "Suspicious activity") return "medium";
  if (reason === "Spam/Telemarketing") return "medium";
  return "low";
}

function validatePhone(country: Country, rawDigits: string): string | null {
  if (!rawDigits) return "Phone number is required.";
  if (rawDigits.length < country.minDigits)
    return `Too short. ${country.name} numbers need ${country.minDigits} digits.`;
  if (rawDigits.length > country.maxDigits)
    return `Too long. ${country.name} numbers need ${country.maxDigits} digits.`;
  if (/^0+$/.test(rawDigits)) return "Phone number can’t be all zeros.";
  return null;
}

export default function FlagsAdd() {
  const router = useRouter();
  const { addFlag } = useFlags();

  const [country, setCountry] = useState<Country>(COUNTRIES[0]);
  const [countryOpen, setCountryOpen] = useState(false);

  const [rawNumber, setRawNumber] = useState("");
  const [reason, setReason] = useState<Reason>("Scam call");
  const [notes, setNotes] = useState("");

  const levelPreview = useMemo(() => reasonToLevel(reason), [reason]);
  const error = useMemo(() => validatePhone(country, rawNumber), [country, rawNumber]);

  const fullNumber = useMemo(() => `${country.dial} ${rawNumber}`, [country.dial, rawNumber]);

  const canSubmit = !error;

  const onSubmit = () => {
    if (!canSubmit) {
      Alert.alert("Fix this first", error || "Invalid number.");
      return;
    }

    const res = addFlag({
      id: `manual-${Date.now()}`,
      number: fullNumber, // ✅ saved with country key
      level: levelPreview,
      reason,
      notes,
      score: levelPreview === "high" ? 85 : levelPreview === "medium" ? 55 : 15,
      keywords: [],
      time: "Manual Entry",
      duration: "—",
    } as any);

    if (!res.ok) {
      Alert.alert("Oops", res.message);
      return;
    }

    const pts = res.pointsAwarded ?? 0;
    Alert.alert("Added ✅", `${res.message}${pts ? `\n\n+${pts} points ⭐` : ""}`, [
      { text: "OK", onPress: () => router.back() },
    ]);
  };

  return (
    <SafeAreaView style={s.safe}>
      <StatusBar barStyle="dark-content" />

      {/* ✅ Country list modal */}
      <Modal visible={countryOpen} transparent animationType="fade" onRequestClose={() => setCountryOpen(false)}>
        <Pressable style={s.modalOverlay} onPress={() => setCountryOpen(false)}>
          <Pressable style={s.modalCard} onPress={() => {}}>
            <View style={s.modalHeader}>
              <Text style={s.modalTitle}>Select Country Key</Text>
              <Pressable onPress={() => setCountryOpen(false)}>
                <Text style={s.modalClose}>Close</Text>
              </Pressable>
            </View>

            <FlatList
              data={COUNTRIES}
              keyExtractor={(item) => item.key}
              renderItem={({ item }) => {
                const selected = item.key === country.key;
                return (
                  <Pressable
                    onPress={() => {
                      setCountry(item);
                      setCountryOpen(false);
                      // optional: clear number if user switches country
                      // setRawNumber("");
                    }}
                    style={[s.countryItem, selected && s.countryItemSelected]}
                  >
                    <View style={s.countryItemLeft}>
                      <Text style={s.countryItemName}>{item.name}</Text>
                      <Text style={s.countryItemHint}>{item.hint}</Text>
                    </View>
                    <Text style={s.countryItemDial}>{item.dial}</Text>
                  </Pressable>
                );
              }}
            />
          </Pressable>
        </Pressable>
      </Modal>

      <ScrollView contentContainerStyle={s.scroll} keyboardShouldPersistTaps="handled">
        <View style={s.content}>
          <Pressable onPress={() => router.back()} style={({ pressed }) => [s.backRow, pressed && s.pressed]}>
            <Text style={s.backArrow}>←</Text>
            <Text style={s.backText}>Back</Text>
          </Pressable>

          <Text style={s.title}>Add Flag</Text>
          <Text style={s.subtitle}>Add a number manually to help detect scams faster.</Text>

          <View style={s.card}>
            <Text style={s.sectionTitle}>Phone Number</Text>

            <View style={s.row}>
              {/* ✅ Opens list */}
              <Pressable
                onPress={() => setCountryOpen(true)}
                style={({ pressed }) => [
                  s.countryBtn,
                  s.countryBtnSelected,
                  pressed && s.pressed,
                ]}
              >
                <Text style={s.countryText}>{country.dial}</Text>
                <Text style={s.countrySub}>{country.name} • {country.hint}</Text>
              </Pressable>

              <TextInput
                value={rawNumber}
                onChangeText={(t) => setRawNumber(digitsOnly(t))}
                placeholder={`Digits only (${country.hint})`}
                placeholderTextColor="#94A3B8"
                style={[s.input, !!error && s.inputError]}
                keyboardType="phone-pad"
              />
            </View>

            {!!error && <Text style={s.errorText}>{error}</Text>}

            <Text style={s.sectionTitle}>Reason for Flagging</Text>
            <View style={s.radioGroup}>
              {REASONS.map((r) => {
                const selected = reason === r;
                return (
                  <Pressable
                    key={r}
                    onPress={() => setReason(r)}
                    style={({ pressed }) => [
                      s.radioRow,
                      selected && s.radioRowSelected,
                      pressed && s.pressed,
                    ]}
                  >
                    <View style={[s.radioOuter, selected && s.radioOuterSelected]}>
                      {selected && <View style={s.radioInner} />}
                    </View>
                    <Text style={s.radioText}>{r}</Text>
                  </Pressable>
                );
              })}
            </View>

            <Text style={s.sectionTitle}>Notes (Optional)</Text>
            <TextInput
              value={notes}
              onChangeText={setNotes}
              placeholder="Add any additional details..."
              placeholderTextColor="#94A3B8"
              style={[s.input, s.notesBox]}
              multiline
            />

            <Text style={s.hint}>
              Will be saved as: <Text style={s.hintStrong}>{fullNumber}</Text>
              {"\n"}Risk level: <Text style={s.hintStrong}>{levelPreview.toUpperCase()}</Text>
            </Text>

            <Pressable
              onPress={onSubmit}
              disabled={!canSubmit}
              style={({ pressed }) => [
                s.submitBtn,
                !canSubmit && s.submitBtnDisabled,
                pressed && canSubmit && s.pressed,
              ]}
            >
              <Text style={s.submitText}>Add to Flag List</Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
