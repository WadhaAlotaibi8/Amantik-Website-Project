import React, { createContext, useContext, useMemo, useState } from "react";

export type RiskLevel = "low" | "medium" | "high";

export type FlagItem = {
  id: string;
  number: string;
  level: RiskLevel;
  reason: string;
  notes?: string;

  score: number; // 0..100
  keywords: string[];
  time: string;
  duration: string;
};

type FlagsContextValue = {
  flags: FlagItem[];
  existsByNumber: (phone: string) => boolean;
  addFlag: (item: FlagItem) => { ok: boolean; message: string };
  removeByNumber: (phone: string) => { ok: boolean; message: string };
};

const FlagsContext = createContext<FlagsContextValue | null>(null);

// simple normalizer so "+965 5000 1234" == "+96550001234"
function normalizePhone(phone: string) {
  return (phone || "").replace(/\s+/g, "").trim().toLowerCase();
}

export function FlagsProvider({
  children,
  initialFlags = [],
}: {
  children: React.ReactNode;
  initialFlags?: FlagItem[];
}) {
  const [flags, setFlags] = useState<FlagItem[]>(initialFlags);

  const value = useMemo<FlagsContextValue>(() => {
    const existsByNumber = (phone: string) => {
      const target = normalizePhone(phone);
      if (!target) return false;
      return flags.some((f) => normalizePhone(f.number) === target);
    };

    const addFlag = (item: FlagItem) => {
      // problem checks
      if (!item) return { ok: false, message: "Missing item." };
      if (!item.number || !normalizePhone(item.number))
        return { ok: false, message: "Phone number is missing." };

      if (existsByNumber(item.number)) {
        return { ok: false, message: "This number is already in your Flag List." };
      }

      // validate score range 
      const safeScore = Number.isFinite(item.score)
        ? Math.max(0, Math.min(100, Math.round(item.score)))
        : 0;

      const safeItem: FlagItem = {
        ...item,
        score: safeScore,
        keywords: Array.isArray(item.keywords) ? item.keywords : [],
      };

      setFlags((prev) => [safeItem, ...prev]);
      return { ok: true, message: "Added to Flag List." };
    };

    const removeByNumber = (phone: string) => {
      const target = normalizePhone(phone);
      if (!target) return { ok: false, message: "Invalid phone number." };
      const before = flags.length;

      setFlags((prev) => prev.filter((f) => normalizePhone(f.number) !== target));

      if (before === 0) return { ok: false, message: "Flag List is empty." };
      return { ok: true, message: "Removed from Flag List." };
    };

    return { flags, existsByNumber, addFlag, removeByNumber };
  }, [flags]);

  return <FlagsContext.Provider value={value}>{children}</FlagsContext.Provider>;
}

export function useFlags() {
  const ctx = useContext(FlagsContext);
  if (!ctx) {
    throw new Error("useFlags() must be used inside <FlagsProvider />");
  }
  return ctx;
}
