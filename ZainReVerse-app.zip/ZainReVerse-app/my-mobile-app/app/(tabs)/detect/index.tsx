// app/(tabs)/detect/index.tsx
import React, { useMemo, useState } from "react";
import {
  View,
  Text,
  SafeAreaView,
  StatusBar,
  Pressable,
  FlatList,
} from "react-native";
import { useRouter } from "expo-router";
import { Shield, Zap, ChevronRight } from "lucide-react-native";
import { styles } from "../../../src/styles/detectStyles";
import { MOCK_CALLS, CallItem } from "../../../src/data/mockCalls";

function dotColor(level: CallItem["level"]) {
  if (level === "high") return "#EF4444";
  if (level === "medium") return "#F59E0B";
  return "#16A34A";
}

function riskText(item: CallItem) {
  if (item.level === "high") return `High Risk • Score ${item.score}/100`;
  if (item.level === "medium") return `Medium Risk • Score ${item.score}/100`;
  return `Low Risk • Score ${item.score}/100`;
}

export default function Detect() {
  const router = useRouter();
  const [enabled, setEnabled] = useState(true);

  const calls = useMemo(() => MOCK_CALLS, []);
  const preview = useMemo(() => calls.slice(0, 3), [calls]);

  const onToggleDetection = () => setEnabled((p) => !p);

  const openDetails = (id: string) => {
    router.push({ pathname: "/detect/call/[id]", params: { id } });
  };

  const openRecents = () => {
    router.push("/detect/recents");
  };

  const Header = (
    <View>
      <StatusBar barStyle="dark-content" />

      <Text style={styles.brand}>Zain ReVerse</Text>
      <Text style={styles.tagline}>Real-time scam call detection</Text>

      {/* BIG CIRCLE — unchanged */}
      <View style={styles.heroWrap}>
        <Pressable
          onPress={onToggleDetection}
          style={({ pressed }) => [
            styles.heroCircle,
            !enabled && styles.heroCircleOff,
            pressed && styles.pressed,
          ]}
        >
          <Shield color="#FFFFFF" size={44} />
          <Text style={styles.heroTitle}>
            {enabled ? "Detection On" : "Detection Off"}
          </Text>
        </Pressable>

        <View style={styles.statusRow}>
          <Zap color="#2563EB" size={18} />
          <Text style={styles.statusText}>{enabled ? "AI Active" : "AI Paused"}</Text>
        </View>

        <Text style={styles.statusHint}>
          {enabled
            ? "Listening for scam indicators..."
            : "Detection is off. Tap the circle to enable."}
        </Text>
      </View>

      {/* Recent header + View all */}
      <View style={styles.sectionHeadRow}>
        <View style={{ flex: 1 }}>
          <Text style={styles.sectionTitle}>Recent Analyzed Calls</Text>
          <Text style={styles.sectionSub}>Preview (latest 3)</Text>
        </View>

        <Pressable
          onPress={openRecents}
          style={({ pressed }) => [styles.viewAllBtn, pressed && styles.pressed]}
        >
          <Text style={styles.viewAllText}>View all</Text>
          <ChevronRight color="#2563EB" size={20} />
        </Pressable>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.safe}>
      <FlatList
        data={preview}
        keyExtractor={(i) => i.id}
        ListHeaderComponent={Header}
        contentContainerStyle={styles.previewListContent}
        renderItem={({ item }) => (
          <Pressable
            onPress={() => openDetails(item.id)}
            style={({ pressed }) => [styles.callCard, pressed && styles.cardPressed]}
          >
            <View style={styles.callRow}>
              <View style={[styles.dot, { backgroundColor: dotColor(item.level) }]} />

              <View style={{ flex: 1 }}>
                <Text style={styles.callNumber}>{item.number}</Text>
                <Text style={styles.callMeta}>{riskText(item)}</Text>
                <Text style={styles.callTime}>{item.timeLabel}</Text>
              </View>

              <ChevronRight color="#94A3B8" size={26} />
            </View>
          </Pressable>
        )}
        ListEmptyComponent={
          <View style={styles.emptyWrap}>
            <Text style={styles.emptyTitle}>No calls analyzed yet</Text>
            <Text style={styles.emptyText}>
              Once detection is enabled and calls are processed, they’ll appear here.
            </Text>
          </View>
        }
      />
    </SafeAreaView>
  );
}
