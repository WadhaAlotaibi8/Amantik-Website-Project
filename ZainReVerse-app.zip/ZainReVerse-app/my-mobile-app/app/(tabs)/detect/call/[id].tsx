import React from "react";
import { CallDetailsScreen } from "../../../../src/screens/CallDetailsScreen";

export default function DetectCallDetails() {
  return <CallDetailsScreen />;
}
