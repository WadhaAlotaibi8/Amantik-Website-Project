import React from "react";
import { CallDetailsScreen } from "../../../src/screens/CallDetailsScreen";

export default function DetectReport() {
  return <CallDetailsScreen />;
}
