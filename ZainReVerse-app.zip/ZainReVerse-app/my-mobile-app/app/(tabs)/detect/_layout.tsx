import { Stack } from "expo-router";

export default function DetectLayout() {
  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="index" />
      <Stack.Screen name="report" />
      <Stack.Screen name="recents" />
      <Stack.Screen name="call/[id]" />
    </Stack>
  );
}
