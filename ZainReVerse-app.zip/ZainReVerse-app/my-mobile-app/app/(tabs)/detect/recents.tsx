import React, { useMemo } from "react";
import { SafeAreaView, View, Text, Pressable, FlatList } from "react-native";
import { useRouter } from "expo-router";
import { ChevronLeft, ChevronRight } from "lucide-react-native";

import { styles } from "../../../src/styles/detectStyles";
import { MOCK_CALLS, CallItem } from "../../../src/data/mockCalls";

function dotColor(level: CallItem["level"]) {
  if (level === "high") return "#EF4444";
  if (level === "medium") return "#F59E0B";
  return "#16A34A";
}

function riskText(item: CallItem) {
  if (item.level === "high") return `High Risk • Score ${item.score}/100`;
  if (item.level === "medium") return `Medium Risk • Score ${item.score}/100`;
  return `Low Risk • Score ${item.score}/100`;
}

function statusLabel(s: CallItem["status"]) {
  if (s === "flagged") return "Flagged";
  if (s === "ignored") return "Ignored";
  if (s === "reported") return "Reported";
  return "";
}

function statusColors(s: CallItem["status"]) {
  if (s === "flagged")
    return {
      bg: "rgba(239,68,68,0.12)",
      border: "rgba(239,68,68,0.35)",
      text: "#EF4444",
    };
  if (s === "ignored")
    return {
      bg: "rgba(100,116,139,0.12)",
      border: "rgba(100,116,139,0.35)",
      text: "#64748B",
    };
  if (s === "reported")
    return {
      bg: "rgba(245,158,11,0.12)",
      border: "rgba(245,158,11,0.35)",
      text: "#F59E0B",
    };
  return null;
}

export default function DetectRecents() {
  const router = useRouter();
  const calls = useMemo(() => MOCK_CALLS, []);

  // ✅ Back to previous page if possible, otherwise fallback
  const goBack = () => {
    if (router.canGoBack()) router.back();
    else router.replace("/detect");
  };

  const openDetails = (id: string) => {
    router.push({ pathname: "/detect/report", params: { id } });
  };

  const Header = (
    <View style={{ paddingHorizontal: 18, paddingTop: 10, paddingBottom: 6 }}>
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <Pressable
          onPress={goBack}
          style={({ pressed }) => [
            {
              flexDirection: "row",
              alignItems: "center",
              gap: 6,
              paddingHorizontal: 10,
              paddingVertical: 8,
              borderRadius: 12,
              borderWidth: 1,
              borderColor: "#E5E7EB",
              backgroundColor: "#F8FAFC",
            },
            pressed && styles.pressed,
          ]}
        >
          <ChevronLeft color="#0F172A" size={22} />
          <Text style={{ color: "#0F172A", fontWeight: "900" }}>Back</Text>
        </Pressable>

        <Text style={{ color: "#0F172A", fontSize: 18, fontWeight: "900" }}>
          Recent Calls
        </Text>

        <View style={{ width: 64 }} />
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.safe}>
      <FlatList
        data={calls}
        keyExtractor={(i) => i.id}
        ListHeaderComponent={Header}
        contentContainerStyle={styles.listContent}
        renderItem={({ item }) => (
          <Pressable
            onPress={() => openDetails(item.id)}
            style={({ pressed }) => [
              styles.callCard,
              pressed && styles.cardPressed,
            ]}
          >
            <View style={styles.callRow}>
              <View
                style={[styles.dot, { backgroundColor: dotColor(item.level) }]}
              />

              <View style={{ flex: 1 }}>
                <Text style={styles.callNumber}>{item.number}</Text>
                <Text style={styles.callMeta}>
                  {riskText(item)} • {item.duration}
                </Text>

                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    gap: 10,
                    marginTop: 4,
                  }}
                >
                  <Text style={styles.callTime}>{item.timeLabel}</Text>

                  {!!statusLabel(item.status) &&
                    (() => {
                      const c = statusColors(item.status);
                      if (!c) return null;
                      return (
                        <View
                          style={{
                            paddingHorizontal: 10,
                            paddingVertical: 5,
                            borderRadius: 999,
                            backgroundColor: c.bg,
                            borderWidth: 1,
                            borderColor: c.border,
                          }}
                        >
                          <Text
                            style={{
                              color: c.text,
                              fontWeight: "900",
                              fontSize: 12,
                            }}
                          >
                            {statusLabel(item.status)}
                          </Text>
                        </View>
                      );
                    })()}
                </View>
              </View>

              <ChevronRight color="#94A3B8" size={26} />
            </View>
          </Pressable>
        )}
      />
    </SafeAreaView>
  );
}
