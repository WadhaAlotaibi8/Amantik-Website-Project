import { Tabs } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { FlagsProvider } from "../../src/context/FlagsContext";
import { MOCK_FLAGS } from "../../src/data/mockFlags";

export default function TabsLayout() {
  return (
    <FlagsProvider initialFlags={MOCK_FLAGS}>
      <Tabs
        initialRouteName="detect" // ✅ IMPORTANT: no /index
        screenOptions={{
          headerShown: false,
          tabBarActiveTintColor: "#2563EB",
          tabBarInactiveTintColor: "#6B7280",
          tabBarStyle: {
            height: 78,
            paddingTop: 10,
            paddingBottom: 16,
            borderTopWidth: 1,
            borderTopColor: "#E5E7EB",
            backgroundColor: "#FFFFFF",
          },
          tabBarLabelStyle: {
            fontSize: 12,
            fontWeight: "700",
            marginTop: -2,
          },
        }}
      >
        {/* ✅ ONLY 3 TABS */}
        <Tabs.Screen
          name="flags"
          options={{
            title: "Flag List",
            tabBarIcon: ({ color, size, focused }) => (
              <Ionicons
                name={focused ? "list" : "list-outline"}
                size={size ?? 24}
                color={color}
              />
            ),
          }}
        />

        <Tabs.Screen
          name="detect"
          options={{
            title: "Detect",
            tabBarIcon: ({ color, size, focused }) => (
              <Ionicons
                name={focused ? "shield" : "shield-outline"}
                size={size ?? 24}
                color={color}
              />
            ),
          }}
        />

        <Tabs.Screen
          name="profile"
          options={{
            title: "Profile",
            tabBarIcon: ({ color, size, focused }) => (
              <Ionicons
                name={focused ? "person" : "person-outline"}
                size={size ?? 24}
                color={color}
              />
            ),
          }}
        />
      </Tabs>
    </FlagsProvider>
  );
}
